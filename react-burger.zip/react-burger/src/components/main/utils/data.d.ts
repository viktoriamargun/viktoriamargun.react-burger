export type ItemType = {
  id: number,
  type: string,
  name: string,
  price: number,
  image: string
}
