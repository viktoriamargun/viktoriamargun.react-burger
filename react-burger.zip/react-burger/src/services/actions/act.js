// загрузка данных (список всех полученных ингредиентов)
const LOADING_DATA = 'LOADING_DATA';

// список всех ингредиентов в текущем конструкторе
const CURRENT_DATA_CONSTRUCTOR = 'CURRENT_DATA_CONSTRUCTOR';
// объект текущего просматриваемого ингредиента
const SELECTED_INGREDIENT_DETAILS = 'SELECTED_INGREDIENT_DETAILS';
// объект создания заказа
const DETAILS_CREATED_ORDER = 'DETAILS_CREATED_ORDER';