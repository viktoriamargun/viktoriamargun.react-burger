export const ItemTypes = {
  INGREDIENT_BUN: 'ingredient_bun',
  INGREDIENT_SAUCE: 'ingredient_sauce',
  INGREDIENT_MAIN: 'ingredient_main',
};